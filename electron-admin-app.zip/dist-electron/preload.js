"use strict";
const electron = require("electron");
electron.contextBridge.exposeInMainWorld("vaultAPI", {
  set: (key, value) => electron.ipcRenderer.invoke("vault:set", key, value),
  get: (key) => electron.ipcRenderer.invoke("vault:get", key),
  delete: (key) => electron.ipcRenderer.invoke("vault:delete", key)
});
electron.contextBridge.exposeInMainWorld("cryptoAPI", {
  signPayload: (payload, secret) => electron.ipcRenderer.invoke("crypto:signPayload", payload, secret)
});
electron.contextBridge.exposeInMainWorld("staffAPI", {
  hashPassword: (plain) => electron.ipcRenderer.invoke("staff:hashPassword", plain),
  verifyPassword: (plain, stored) => electron.ipcRenderer.invoke("staff:verifyPassword", plain, stored),
  encryptSecret: (plain) => electron.ipcRenderer.invoke("staff:encryptSecret", plain),
  decryptSecret: (enc) => electron.ipcRenderer.invoke("staff:decryptSecret", enc)
});
electron.contextBridge.exposeInMainWorld("updaterAPI", {
  check: () => electron.ipcRenderer.invoke("updater:check"),
  download: () => electron.ipcRenderer.invoke("updater:download"),
  install: () => electron.ipcRenderer.invoke("updater:install"),
  setFeedUrl: (url) => electron.ipcRenderer.invoke("updater:setFeedUrl", url),
  getFeedUrl: () => electron.ipcRenderer.invoke("updater:getFeedUrl"),
  onAvailable: (cb) => electron.ipcRenderer.on("updater:available", (_e, data) => cb(data)),
  onProgress: (cb) => electron.ipcRenderer.on("updater:progress", (_e, data) => cb(data)),
  onDownloaded: (cb) => electron.ipcRenderer.on("updater:downloaded", (_e, data) => cb(data)),
  onError: (cb) => electron.ipcRenderer.on("updater:error", (_e, data) => cb(data))
});
electron.contextBridge.exposeInMainWorld("appAPI", {
  getVersion: () => electron.ipcRenderer.invoke("app:getVersion")
});
electron.contextBridge.exposeInMainWorld("windowAPI", {
  minimize: () => electron.ipcRenderer.invoke("window:minimize"),
  maximizeToggle: () => electron.ipcRenderer.invoke("window:maximizeToggle"),
  hide: () => electron.ipcRenderer.invoke("window:hide"),
  restartApp: () => electron.ipcRenderer.invoke("window:restartApp"),
  quitApp: () => electron.ipcRenderer.invoke("window:quitApp")
});
electron.contextBridge.exposeInMainWorld("mssqlAPI", {
  testConnection: (input) => electron.ipcRenderer.invoke("mssql:testConnection", input),
  listDatabases: (input) => electron.ipcRenderer.invoke("mssql:listDatabases", input),
  executeQuery: (input) => electron.ipcRenderer.invoke("mssql:executeQuery", input)
});
electron.contextBridge.exposeInMainWorld("dbAPI", {
  exportSnapshot: () => electron.ipcRenderer.invoke("db:exportSnapshot"),
  upsertCompany: (company) => electron.ipcRenderer.invoke("db:upsertCompany", company),
  deleteCompany: (id) => electron.ipcRenderer.invoke("db:deleteCompany", id),
  upsertConnection: (conn) => electron.ipcRenderer.invoke("db:upsertConnection", conn),
  deleteConnection: (id) => electron.ipcRenderer.invoke("db:deleteConnection", id),
  upsertStaff: (member) => electron.ipcRenderer.invoke("db:upsertStaff", member),
  deleteStaff: (id) => electron.ipcRenderer.invoke("db:deleteStaff", id),
  upsertEndpoint: (ep) => electron.ipcRenderer.invoke("db:upsertEndpoint", ep),
  deleteEndpoint: (id) => electron.ipcRenderer.invoke("db:deleteEndpoint", id),
  getSettings: () => electron.ipcRenderer.invoke("db:getSettings"),
  updateSettings: (patch) => electron.ipcRenderer.invoke("db:updateSettings", patch),
  listSyncQueue: () => electron.ipcRenderer.invoke("db:listSyncQueue"),
  enqueueSync: (item) => electron.ipcRenderer.invoke("db:enqueueSync", item),
  updateSyncQueueItem: (id, patch) => electron.ipcRenderer.invoke("db:updateSyncQueueItem", id, patch),
  removeSyncQueueItem: (id) => electron.ipcRenderer.invoke("db:removeSyncQueueItem", id),
  getSyncMeta: () => electron.ipcRenderer.invoke("db:getSyncMeta"),
  updateSyncMeta: (patch) => electron.ipcRenderer.invoke("db:updateSyncMeta", patch)
});
electron.contextBridge.exposeInMainWorld("appLockAPI", {
  hasPassword: () => electron.ipcRenderer.invoke("appLock:hasPassword"),
  setPassword: (plain) => electron.ipcRenderer.invoke("appLock:setPassword", plain),
  clearPassword: () => electron.ipcRenderer.invoke("appLock:clearPassword"),
  verify: (plain) => electron.ipcRenderer.invoke("appLock:verify", plain)
});
electron.contextBridge.exposeInMainWorld("trayAPI", {
  setStatus: (status) => electron.ipcRenderer.invoke("tray:setStatus", status)
});
