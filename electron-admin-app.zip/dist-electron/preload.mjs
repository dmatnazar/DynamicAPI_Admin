"use strict";
const electron = require("electron");
electron.contextBridge.exposeInMainWorld("vaultAPI", {
  set: (key, value) => electron.ipcRenderer.invoke("vault:set", key, value),
  get: (key) => electron.ipcRenderer.invoke("vault:get", key),
  delete: (key) => electron.ipcRenderer.invoke("vault:delete", key)
});
electron.contextBridge.exposeInMainWorld("cryptoAPI", {
  signPayload: (payload, secret) => electron.ipcRenderer.invoke("crypto:signPayload", payload, secret)
});
electron.contextBridge.exposeInMainWorld("staffAPI", {
  hashPassword: (plain) => electron.ipcRenderer.invoke("staff:hashPassword", plain),
  verifyPassword: (plain, stored) => electron.ipcRenderer.invoke("staff:verifyPassword", plain, stored)
});
electron.contextBridge.exposeInMainWorld("updaterAPI", {
  check: () => electron.ipcRenderer.invoke("updater:check"),
  download: () => electron.ipcRenderer.invoke("updater:download"),
  install: () => electron.ipcRenderer.invoke("updater:install"),
  onAvailable: (cb) => electron.ipcRenderer.on("updater:available", (_e, data) => cb(data)),
  onProgress: (cb) => electron.ipcRenderer.on("updater:progress", (_e, data) => cb(data)),
  onDownloaded: (cb) => electron.ipcRenderer.on("updater:downloaded", (_e, data) => cb(data)),
  onError: (cb) => electron.ipcRenderer.on("updater:error", (_e, data) => cb(data))
});
electron.contextBridge.exposeInMainWorld("appAPI", {
  getVersion: () => electron.ipcRenderer.invoke("app:getVersion")
});
electron.contextBridge.exposeInMainWorld("windowAPI", {
  minimize: () => electron.ipcRenderer.invoke("window:minimize"),
  maximizeToggle: () => electron.ipcRenderer.invoke("window:maximizeToggle"),
  hide: () => electron.ipcRenderer.invoke("window:hide"),
  restartApp: () => electron.ipcRenderer.invoke("window:restartApp"),
  quitApp: () => electron.ipcRenderer.invoke("window:quitApp")
});
