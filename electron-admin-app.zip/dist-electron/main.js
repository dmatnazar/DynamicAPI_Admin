"use strict";
const electron = require("electron");
const path = require("node:path");
const fs = require("node:fs");
const crypto = require("node:crypto");
const electronUpdater = require("electron-updater");
const log = require("electron-log");
const sql = require("mssql");
electronUpdater.autoUpdater.logger = log;
electronUpdater.autoUpdater.autoDownload = false;
electronUpdater.autoUpdater.autoInstallOnAppQuit = true;
function initAutoUpdater(mainWindow2) {
  const send = (channel, payload) => {
    if (!mainWindow2.isDestroyed()) mainWindow2.webContents.send(channel, payload);
  };
  electronUpdater.autoUpdater.on("checking-for-update", () => send("updater:checking"));
  electronUpdater.autoUpdater.on("update-available", (info) => {
    send("updater:available", { version: info.version });
  });
  electronUpdater.autoUpdater.on("update-not-available", () => send("updater:none"));
  electronUpdater.autoUpdater.on("download-progress", (progress) => {
    send("updater:progress", {
      percent: Math.round(progress.percent),
      bytesPerSecond: progress.bytesPerSecond,
      transferred: progress.transferred,
      total: progress.total
    });
  });
  electronUpdater.autoUpdater.on("update-downloaded", (info) => {
    send("updater:downloaded", { version: info.version });
  });
  electronUpdater.autoUpdater.on("error", (err) => {
    send("updater:error", { message: err.message });
  });
  electron.ipcMain.handle("updater:check", () => electronUpdater.autoUpdater.checkForUpdates().catch((e) => log.error(e)));
  electron.ipcMain.handle("updater:download", () => electronUpdater.autoUpdater.downloadUpdate());
  electron.ipcMain.handle("updater:install", () => {
    setImmediate(() => electronUpdater.autoUpdater.quitAndInstall(false, true));
  });
  try {
    electronUpdater.autoUpdater.checkForUpdates().catch(() => {
    });
  } catch {
  }
  setInterval(() => {
    electronUpdater.autoUpdater.checkForUpdates().catch(() => {
    });
  }, 4 * 60 * 60 * 1e3);
}
let tray = null;
const FALLBACK_ICON_DATA_URL = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAGklEQVR4nGNQuvzuPyWYYdSAUQNGDRguBgAAEtbiH+8clfcAAAAASUVORK5CYII=";
function resolveIcon() {
  const packagedPath = path.join(process.resourcesPath ?? "", "build", "tray-icon.png");
  const devPath = path.join(__dirname, "../build/tray-icon.png");
  const candidate = electron.app.isPackaged ? packagedPath : devPath;
  const img = electron.nativeImage.createFromPath(candidate);
  if (!img.isEmpty()) return img.resize({ width: 16, height: 16 });
  return electron.nativeImage.createFromDataURL(FALLBACK_ICON_DATA_URL).resize({ width: 16, height: 16 });
}
function createTray(hooks) {
  if (tray) return tray;
  tray = new electron.Tray(resolveIcon());
  tray.setToolTip("Dynamic API Admin");
  const buildMenu = () => {
    const win = hooks.getWindow();
    const visible = !!win && win.isVisible();
    return electron.Menu.buildFromTemplate([
      { label: "Dynamic API Admin", enabled: false },
      { type: "separator" },
      {
        label: visible ? "Bring to front" : "Show window",
        click: hooks.onShow
      },
      {
        label: "Hide window",
        enabled: visible,
        click: () => {
          var _a;
          return (_a = hooks.getWindow()) == null ? void 0 : _a.hide();
        }
      },
      { type: "separator" },
      { label: "Restart app", click: hooks.onRestart },
      { label: "Quit", click: hooks.onQuit }
    ]);
  };
  tray.on("click", hooks.onShow);
  tray.on("right-click", () => tray == null ? void 0 : tray.popUpContextMenu(buildMenu()));
  tray.setContextMenu(buildMenu());
  return tray;
}
function destroyTray() {
  tray == null ? void 0 : tray.destroy();
  tray = null;
}
const DB_VERSION = 2;
function dbPath() {
  return path.join(electron.app.getPath("userData"), "local-admin.db.json");
}
function emptyDb() {
  return {
    version: DB_VERSION,
    companies: [],
    connections: [],
    staff: [],
    endpoints: [],
    settings: { gatewayUrl: "", adminSecretEnc: "" },
    syncQueue: [],
    syncMeta: { autoSyncIntervalSec: 30 }
  };
}
function readRaw() {
  const p = dbPath();
  if (!fs.existsSync(p)) return emptyDb();
  try {
    const data = JSON.parse(fs.readFileSync(p, "utf8"));
    if (!Array.isArray(data.syncQueue)) data.syncQueue = [];
    if (!data.syncMeta) data.syncMeta = { autoSyncIntervalSec: 30 };
    data.version = DB_VERSION;
    if (!data.version) return emptyDb();
    return {
      ...emptyDb(),
      ...data,
      companies: data.companies ?? [],
      connections: data.connections ?? [],
      staff: data.staff ?? [],
      endpoints: data.endpoints ?? [],
      settings: { ...emptyDb().settings, ...data.settings ?? {} }
    };
  } catch {
    return emptyDb();
  }
}
function writeRaw(db) {
  const p = dbPath();
  fs.mkdirSync(path.dirname(p), { recursive: true });
  fs.writeFileSync(p, JSON.stringify(db, null, 2), "utf8");
}
function encryptSecret(plain) {
  if (!plain) return "";
  if (!electron.safeStorage.isEncryptionAvailable()) {
    return Buffer.from(plain, "utf8").toString("base64");
  }
  return electron.safeStorage.encryptString(plain).toString("base64");
}
function decryptSecret(enc) {
  if (!enc) return "";
  try {
    if (electron.safeStorage.isEncryptionAvailable()) {
      return electron.safeStorage.decryptString(Buffer.from(enc, "base64"));
    }
    return Buffer.from(enc, "base64").toString("utf8");
  } catch {
    return "";
  }
}
function upsertCompany(company) {
  const db = readRaw();
  const idx = db.companies.findIndex((c) => c.id === company.id);
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const row = {
    ...company,
    updatedAt: now,
    createdAt: company.createdAt || now
  };
  if (idx >= 0) db.companies[idx] = row;
  else db.companies.push(row);
  writeRaw(db);
  return row;
}
function deleteCompany(id) {
  const db = readRaw();
  const before = db.companies.length;
  db.companies = db.companies.filter((c) => c.id !== id);
  db.connections = db.connections.filter((c) => c.companyId !== id);
  db.endpoints = db.endpoints.filter((e) => e.companyId !== id);
  db.staff = db.staff.map((s) => ({
    ...s,
    tenantIds: s.tenantIds.filter((t) => t !== id)
  }));
  writeRaw(db);
  return db.companies.length < before;
}
function upsertConnection(conn) {
  const db = readRaw();
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const row = {
    ...conn,
    updatedAt: now,
    createdAt: conn.createdAt || now
  };
  if (row.isPrimary) {
    db.connections = db.connections.map(
      (c) => c.companyId === row.companyId && c.id !== row.id ? { ...c, isPrimary: false } : c
    );
  }
  const idx = db.connections.findIndex((c) => c.id === row.id);
  if (idx >= 0) db.connections[idx] = row;
  else db.connections.push(row);
  writeRaw(db);
  return row;
}
function deleteConnection(id) {
  const db = readRaw();
  const removed = db.connections.find((c) => c.id === id);
  db.connections = db.connections.filter((c) => c.id !== id);
  if (removed == null ? void 0 : removed.isPrimary) {
    const siblings = db.connections.filter((c) => c.companyId === removed.companyId);
    if (siblings[0]) {
      siblings[0].isPrimary = true;
    }
  }
  writeRaw(db);
  return !!removed;
}
function upsertStaff(member) {
  const db = readRaw();
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const row = {
    ...member,
    updatedAt: now,
    createdAt: member.createdAt || now
  };
  const idx = db.staff.findIndex((s) => s.id === row.id);
  if (idx >= 0) db.staff[idx] = row;
  else db.staff.push(row);
  writeRaw(db);
  return row;
}
function deleteStaff(id) {
  const db = readRaw();
  const before = db.staff.length;
  db.staff = db.staff.filter((s) => s.id !== id);
  writeRaw(db);
  return db.staff.length < before;
}
function upsertEndpoint(ep) {
  const db = readRaw();
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const row = {
    ...ep,
    updatedAt: now,
    createdAt: ep.createdAt || now
  };
  const idx = db.endpoints.findIndex((e) => e.id === row.id);
  if (idx >= 0) db.endpoints[idx] = row;
  else db.endpoints.push(row);
  writeRaw(db);
  return row;
}
function deleteEndpoint(id) {
  const db = readRaw();
  const before = db.endpoints.length;
  db.endpoints = db.endpoints.filter((e) => e.id !== id);
  writeRaw(db);
  return db.endpoints.length < before;
}
function getSettings() {
  return readRaw().settings;
}
function updateSettings(patch) {
  const db = readRaw();
  db.settings = { ...db.settings, ...patch };
  writeRaw(db);
  return db.settings;
}
function exportSnapshot() {
  const db = readRaw();
  return {
    companies: db.companies,
    connections: db.connections.map((c) => ({
      ...c,
      password: decryptSecret(c.passwordEnc),
      passwordEnc: void 0
    })),
    staff: db.staff,
    endpoints: db.endpoints,
    settings: {
      gatewayUrl: db.settings.gatewayUrl,
      adminSecret: decryptSecret(db.settings.adminSecretEnc || "")
    }
  };
}
function listSyncQueue() {
  return readRaw().syncQueue || [];
}
function enqueueSync(item) {
  const db = readRaw();
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const existing = (db.syncQueue || []).find(
    (q) => q.status === "pending" && q.type === item.type && (q.tenantSlug || "") === (item.tenantSlug || "")
  );
  if (existing) {
    existing.updatedAt = now;
    existing.payload = item.payload ?? existing.payload;
    writeRaw(db);
    return existing;
  }
  const row = {
    id: item.id || `sq-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    type: item.type,
    tenantSlug: item.tenantSlug,
    payload: item.payload,
    attempts: 0,
    lastError: void 0,
    status: "pending",
    createdAt: now,
    updatedAt: now
  };
  db.syncQueue = [...db.syncQueue || [], row];
  writeRaw(db);
  return row;
}
function updateSyncQueueItem(id, patch) {
  const db = readRaw();
  const idx = (db.syncQueue || []).findIndex((q) => q.id === id);
  if (idx < 0) return null;
  db.syncQueue[idx] = {
    ...db.syncQueue[idx],
    ...patch,
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  writeRaw(db);
  return db.syncQueue[idx];
}
function removeSyncQueueItem(id) {
  const db = readRaw();
  const before = (db.syncQueue || []).length;
  db.syncQueue = (db.syncQueue || []).filter((q) => q.id !== id);
  writeRaw(db);
  return db.syncQueue.length < before;
}
function getSyncMeta() {
  return readRaw().syncMeta || { autoSyncIntervalSec: 30 };
}
function updateSyncMeta(patch) {
  const db = readRaw();
  db.syncMeta = { ...db.syncMeta || { autoSyncIntervalSec: 30 }, ...patch };
  writeRaw(db);
  return db.syncMeta;
}
function toConfig(input, database) {
  return {
    server: input.host,
    port: input.port && input.port > 0 ? input.port : 1433,
    database: database || input.database || "master",
    user: input.username,
    password: input.password,
    options: {
      encrypt: input.encrypt !== false,
      trustServerCertificate: input.trustServerCertificate !== false,
      enableArithAbort: true,
      connectTimeout: 15e3
    },
    connectionTimeout: 15e3,
    requestTimeout: 3e4
  };
}
async function testMssqlConnection(input) {
  var _a, _b, _c, _d, _e;
  let pool = null;
  try {
    if (!((_a = input.host) == null ? void 0 : _a.trim())) return { ok: false, message: "Server (host) boş" };
    if (!((_b = input.username) == null ? void 0 : _b.trim())) return { ok: false, message: "Ulanyjy ady boş" };
    pool = await new sql.ConnectionPool(
      toConfig(input, input.database || "master")
    ).connect();
    const r = await pool.request().query("SELECT @@VERSION AS v");
    const serverVersion = (_e = String(((_d = (_c = r.recordset) == null ? void 0 : _c[0]) == null ? void 0 : _d.v) || "").split("\n")[0]) == null ? void 0 : _e.slice(0, 120);
    return { ok: true, serverVersion };
  } catch (err) {
    const message = err.message || String(err);
    return { ok: false, message };
  } finally {
    try {
      await (pool == null ? void 0 : pool.close());
    } catch {
    }
  }
}
async function listMssqlDatabases(input) {
  var _a, _b;
  let pool = null;
  try {
    if (!((_a = input.host) == null ? void 0 : _a.trim())) return { ok: false, message: "Server (host) boş" };
    if (!((_b = input.username) == null ? void 0 : _b.trim())) return { ok: false, message: "Ulanyjy ady boş" };
    pool = await new sql.ConnectionPool(toConfig(input, "master")).connect();
    const r = await pool.request().query(`
      SELECT name
      FROM sys.databases
      WHERE state = 0
        AND name NOT IN ('master', 'tempdb', 'model', 'msdb')
      ORDER BY name
    `);
    const databases = (r.recordset || []).map((row) => row.name);
    return { ok: true, databases };
  } catch (err) {
    const message = err.message || String(err);
    return { ok: false, message };
  } finally {
    try {
      await (pool == null ? void 0 : pool.close());
    } catch {
    }
  }
}
async function executeMssqlQuery(input) {
  var _a, _b, _c;
  let pool = null;
  const t0 = Date.now();
  try {
    if (!((_a = input.host) == null ? void 0 : _a.trim())) return { ok: false, message: "Server (host) boş" };
    if (!((_b = input.username) == null ? void 0 : _b.trim())) return { ok: false, message: "Ulanyjy ady boş" };
    if (!((_c = input.sqlQuery) == null ? void 0 : _c.trim())) return { ok: false, message: "SQL sorag boş" };
    pool = await new sql.ConnectionPool(toConfig(input, input.database)).connect();
    const request = pool.request();
    if (input.params) {
      for (const [key, value] of Object.entries(input.params)) {
        const name = key.startsWith("@") ? key.slice(1) : key;
        request.input(name, value);
      }
    }
    const result = await request.query(input.sqlQuery);
    const rows = result.recordset || [];
    return {
      ok: true,
      rows,
      rowCount: rows.length,
      elapsedMs: Date.now() - t0
    };
  } catch (err) {
    return {
      ok: false,
      message: err.message || String(err)
    };
  } finally {
    try {
      await (pool == null ? void 0 : pool.close());
    } catch {
    }
  }
}
electron.app.disableHardwareAcceleration();
const isDev = !electron.app.isPackaged;
const VAULT_PATH = path.join(electron.app.getPath("userData"), "vault.json");
const AUTO_OPEN_DEVTOOLS = process.env.OPEN_DEVTOOLS === "1";
let mainWindow = null;
let isQuitting = false;
electron.Menu.setApplicationMenu(null);
function createWindow() {
  mainWindow = new electron.BrowserWindow({
    width: 1360,
    height: 860,
    minWidth: 900,
    minHeight: 560,
    backgroundColor: "#0A0B0F",
    titleBarStyle: "hiddenInset",
    autoHideMenuBar: true,
    show: false,
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false
    }
  });
  mainWindow.setMenu(null);
  mainWindow.setMenuBarVisibility(false);
  if (isDev && process.env.VITE_DEV_SERVER_URL) {
    mainWindow.loadURL(process.env.VITE_DEV_SERVER_URL);
    if (AUTO_OPEN_DEVTOOLS) mainWindow.webContents.openDevTools({ mode: "detach" });
  } else {
    mainWindow.loadFile(path.join(__dirname, "../dist/index.html"));
  }
  mainWindow.once("ready-to-show", () => {
    mainWindow == null ? void 0 : mainWindow.show();
  });
  mainWindow.on("close", (e) => {
    if (!isQuitting) {
      e.preventDefault();
      mainWindow == null ? void 0 : mainWindow.hide();
    }
  });
  mainWindow.on("closed", () => {
    mainWindow = null;
  });
  initAutoUpdater(mainWindow);
}
electron.app.whenReady().then(() => {
  createWindow();
  createTray({
    getWindow: () => mainWindow,
    onShow: () => {
      if (!mainWindow) return createWindow();
      mainWindow.show();
      mainWindow.focus();
    },
    onRestart: () => {
      electron.app.relaunch();
      isQuitting = true;
      electron.app.quit();
    },
    onQuit: () => {
      isQuitting = true;
      electron.app.quit();
    }
  });
  electron.app.on("activate", () => {
    if (electron.BrowserWindow.getAllWindows().length === 0) createWindow();
    else mainWindow == null ? void 0 : mainWindow.show();
  });
});
electron.app.on("before-quit", () => {
  isQuitting = true;
  destroyTray();
});
electron.app.on("window-all-closed", () => {
  if (process.platform !== "darwin" && isQuitting) electron.app.quit();
});
electron.ipcMain.handle("window:minimize", () => mainWindow == null ? void 0 : mainWindow.minimize());
electron.ipcMain.handle("window:maximizeToggle", () => {
  if (!mainWindow) return;
  if (mainWindow.isMaximized()) mainWindow.unmaximize();
  else mainWindow.maximize();
});
electron.ipcMain.handle("window:hide", () => mainWindow == null ? void 0 : mainWindow.hide());
electron.ipcMain.handle("window:restartApp", () => {
  electron.app.relaunch();
  isQuitting = true;
  electron.app.quit();
});
electron.ipcMain.handle("window:quitApp", () => {
  isQuitting = true;
  electron.app.quit();
});
function readVault() {
  if (!fs.existsSync(VAULT_PATH)) return {};
  try {
    return JSON.parse(fs.readFileSync(VAULT_PATH, "utf8"));
  } catch {
    return {};
  }
}
function writeVault(vault) {
  fs.writeFileSync(VAULT_PATH, JSON.stringify(vault, null, 2), "utf8");
}
electron.ipcMain.handle("vault:set", (_e, key, value) => {
  if (!electron.safeStorage.isEncryptionAvailable()) {
    throw new Error("OS-level secure storage is not available on this machine");
  }
  const vault = readVault();
  vault[key] = electron.safeStorage.encryptString(value).toString("base64");
  writeVault(vault);
  return true;
});
electron.ipcMain.handle("vault:get", (_e, key) => {
  const vault = readVault();
  const enc = vault[key];
  if (!enc) return null;
  return electron.safeStorage.decryptString(Buffer.from(enc, "base64"));
});
electron.ipcMain.handle("vault:delete", (_e, key) => {
  const vault = readVault();
  delete vault[key];
  writeVault(vault);
  return true;
});
electron.ipcMain.handle("crypto:signPayload", (_e, payload, secret) => {
  const body = JSON.stringify(payload);
  return crypto.createHmac("sha256", secret).update(body).digest("hex");
});
electron.ipcMain.handle("staff:hashPassword", (_e, plain) => {
  const salt = crypto.randomBytes(16).toString("hex");
  const hash = crypto.scryptSync(plain, salt, 64).toString("hex");
  return `${salt}:${hash}`;
});
electron.ipcMain.handle("staff:verifyPassword", (_e, plain, stored) => {
  const [salt, hash] = (stored || "").split(":");
  if (!salt || !hash) return false;
  const candidate = crypto.scryptSync(plain, salt, 64).toString("hex");
  const a = Buffer.from(hash, "hex");
  const b = Buffer.from(candidate, "hex");
  return a.length === b.length && crypto.timingSafeEqual(a, b);
});
electron.ipcMain.handle("staff:encryptSecret", (_e, plain) => {
  if (!electron.safeStorage.isEncryptionAvailable()) {
    return Buffer.from(plain, "utf8").toString("base64");
  }
  return electron.safeStorage.encryptString(plain).toString("base64");
});
electron.ipcMain.handle("staff:decryptSecret", (_e, enc) => {
  if (!enc) return "";
  try {
    if (!electron.safeStorage.isEncryptionAvailable()) {
      return Buffer.from(enc, "base64").toString("utf8");
    }
    return electron.safeStorage.decryptString(Buffer.from(enc, "base64"));
  } catch {
    return "";
  }
});
electron.ipcMain.handle("app:getVersion", () => electron.app.getVersion());
electron.ipcMain.handle("mssql:testConnection", async (_e, input) => {
  return testMssqlConnection(input);
});
electron.ipcMain.handle("mssql:listDatabases", async (_e, input) => {
  return listMssqlDatabases(input);
});
electron.ipcMain.handle("db:exportSnapshot", () => exportSnapshot());
electron.ipcMain.handle("db:upsertCompany", (_e, company) => {
  return upsertCompany(company);
});
electron.ipcMain.handle("db:deleteCompany", (_e, id) => deleteCompany(id));
electron.ipcMain.handle("db:upsertConnection", (_e, conn) => {
  const passwordEnc = conn.password !== void 0 ? encryptSecret(conn.password) : conn.passwordEnc || "";
  const { password: _p, ...rest } = conn;
  return upsertConnection({ ...rest, passwordEnc });
});
electron.ipcMain.handle("db:deleteConnection", (_e, id) => deleteConnection(id));
electron.ipcMain.handle("db:upsertStaff", (_e, member) => upsertStaff(member));
electron.ipcMain.handle("db:deleteStaff", (_e, id) => deleteStaff(id));
electron.ipcMain.handle("db:upsertEndpoint", (_e, ep) => upsertEndpoint(ep));
electron.ipcMain.handle("db:deleteEndpoint", (_e, id) => deleteEndpoint(id));
electron.ipcMain.handle("db:getSettings", () => {
  const s = getSettings();
  return {
    gatewayUrl: s.gatewayUrl,
    adminSecret: decryptSecret(s.adminSecretEnc || "")
  };
});
electron.ipcMain.handle("db:updateSettings", (_e, patch) => {
  const next = {};
  if (patch.gatewayUrl !== void 0) next.gatewayUrl = patch.gatewayUrl;
  if (patch.adminSecret !== void 0) next.adminSecretEnc = encryptSecret(patch.adminSecret);
  const s = updateSettings(next);
  return {
    gatewayUrl: s.gatewayUrl,
    adminSecret: decryptSecret(s.adminSecretEnc || "")
  };
});
electron.ipcMain.handle("db:listSyncQueue", () => listSyncQueue());
electron.ipcMain.handle(
  "db:enqueueSync",
  (_e, item) => enqueueSync(item)
);
electron.ipcMain.handle(
  "db:updateSyncQueueItem",
  (_e, id, patch) => updateSyncQueueItem(id, patch)
);
electron.ipcMain.handle("db:removeSyncQueueItem", (_e, id) => removeSyncQueueItem(id));
electron.ipcMain.handle("db:getSyncMeta", () => getSyncMeta());
electron.ipcMain.handle(
  "db:updateSyncMeta",
  (_e, patch) => updateSyncMeta(patch)
);
electron.ipcMain.handle("mssql:executeQuery", async (_e, input) => {
  return executeMssqlQuery(input);
});
